import java.util.Properties

object DatabaseConnection {
  
  // Database configuration
  private val jdbcUrl: String = "jdbc:postgresql://ec2-18-132-73-146.eu-west-2.compute.amazonaws.com/testdb"
  private val dbUsername: String = "consultants"
  private val dbPassword: String = "WelcomeItc@2022"
  private val dbDriver: String = "org.postgresql.Driver" // Use the correct drive for your DB

  // Method to get the connection properties
  def getJdbcProperties: Properties = {
    val props = new Properties()
    props.setProperty("user", dbUsername)
    props.setProperty("password", dbPassword)
    props.setProperty("driver", dbDriver)
    props
  }

  // Method to get the JDBC URL
  def getJdbcUrl: String = jdbcUrl
}
