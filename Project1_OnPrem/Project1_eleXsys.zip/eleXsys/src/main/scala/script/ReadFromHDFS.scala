import org.apache.spark.sql.SparkSession

object ReadUIfromHdfs extends App {

  // Initialize Spark session
  val spark = SparkSession.builder()
    .appName("Read User Interaction Parquet Data")
    .config("spark.hadoop.fs.defaultFS", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022")
    .getOrCreate()

  // Path to the directory containing Parquet files for user_interaction data
  val parquetDirPath = "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/ui_data"

  // Read the Parquet files from the directory (handles multiple files)
  val parquetDF = spark.read.parquet(parquetDirPath)

  // Show the data (limit to 20 rows)
  parquetDF.show(20)

  // Print schema of the DataFrame
  parquetDF.printSchema()

  // Print the total number of rows in the DataFrame
  val rowCount = parquetDF.count()
  println(s"Total number of rows in the Parquet file: $rowCount")

  // Print the Parquet metadata (schema)
  val metadata = parquetDF.schema.fields.map(field => s"${field.name}: ${field.dataType.simpleString}")
  println("Parquet File Schema:")
  metadata.foreach(println)

  spark.stop()
}