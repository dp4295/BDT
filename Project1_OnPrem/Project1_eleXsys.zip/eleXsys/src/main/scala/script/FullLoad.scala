import java.sql.Timestamp
import java.time.Instant
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import scala.io.StdIn
import scala.util.Try
import org.apache.log4j.{Level, Logger}

object FullLoadWithChangeDetection extends App {




  Logger.getLogger("org").setLevel(Level.WARN)
  Logger.getLogger("akka").setLevel(Level.WARN)

  val spark = SparkSession.builder()
    .appName("FullLoadWithChangeDetection")
    .config("spark.hadoop.fs.defaultFS", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022")
    .config("spark.jars", "/usr/local/lib/postgresql-42.2.18.jar")
    .getOrCreate()
    
    spark.sparkContext.setLogLevel("WARN")

  // Function to load data from Postgres and add load timestamp
  def loadData(tableName: String, hdfsPath: String): Unit = {
    val jdbcUrl = DatabaseConnection.getJdbcUrl
    val jdbcProps = DatabaseConnection.getJdbcProperties

    // Query to fetch data from Postgres
    val query = s"(SELECT * FROM $tableName) AS $tableName"

    // Load data from Postgres
    val dataDF = spark.read
      .option("header", "true")
      .jdbc(jdbcUrl, query, jdbcProps)

    // Add load timestamp
    val loadTimestamp = Timestamp.from(Instant.now())
    val dataWithTimestampDF = dataDF.withColumn("load_timestamp", lit(loadTimestamp))

    // Show the loaded data (for verification)
    dataWithTimestampDF.show(20)

    // Write the data to HDFS in Parquet format with the `load_timestamp` column
    dataWithTimestampDF.write
      .mode(SaveMode.Overwrite)
      .parquet(hdfsPath)
  }

  // Function to check if data has changed in Postgres or if new rows are added
  def hasDataChanged(tableName: String, hdfsPath: String): Boolean = {
    val jdbcUrl = DatabaseConnection.getJdbcUrl
    val jdbcProps = DatabaseConnection.getJdbcProperties

    // Fetch the latest last_modified_timestamp and row count from Postgres
    val query = s"(SELECT MAX(last_modified_timestamp) as max_ts, COUNT(*) as total_records FROM $tableName) AS latest"
    val latestStatsDF = spark.read
      .jdbc(jdbcUrl, query, jdbcProps)

    // Extract the max timestamp and row count
    val latestTimestamp = latestStatsDF.collect()(0).getAs[Timestamp]("max_ts")
    val latestRowCount = latestStatsDF.collect()(0).getAs[Long]("total_records")

    // Fetch the latest load timestamp and row count from HDFS (if it exists)
    val lastLoadStats = Try {
      val hdfsDF = spark.read.parquet(hdfsPath)
      val lastLoadTimestamp = hdfsDF.agg(max("load_timestamp")).collect()(0).getAs[Timestamp]("max(load_timestamp)")
      val lastLoadRowCount = hdfsDF.count()
      (Some(lastLoadTimestamp), lastLoadRowCount)
    }.getOrElse((None, 0L)) // If no previous load, set row count to 0

    val (lastLoadTimestamp, lastLoadRowCount) = lastLoadStats

    // Check if either the data has changed (timestamp) or new rows are added (row count)
    lastLoadTimestamp match {
      case Some(loadTimestamp) => latestTimestamp.after(loadTimestamp) || latestRowCount > lastLoadRowCount
      case None => true // If there's no previous load, consider it as changed
    }
  }

  // Function to show max load timestamp for a table
  def showMaxLoadTimestamp(hdfsPath: String, tableName: String): Unit = {
    Try {
      val hdfsDF = spark.read.parquet(hdfsPath)
      val maxLoadTimestamp = hdfsDF.agg(max("load_timestamp")).collect()(0).getAs[Timestamp]("max(load_timestamp)")
      println(s"Max load_timestamp for $tableName: $maxLoadTimestamp")
    }.getOrElse {
      println(s"No data found in HDFS for $tableName")
    }
  }

  // Function to compare row count before and after full load
  def showRowCountComparison(hdfsPath: String, tableName: String, previousRowCount: Long): Unit = {
    Try {
      val hdfsDF = spark.read.parquet(hdfsPath)
      val newRowCount = hdfsDF.count()
      println(s"Row count for $tableName: Before = $previousRowCount, After = $newRowCount")
    }.getOrElse {
      println(s"No data found in HDFS for $tableName")
    }
  }

  // Function to perform full load if changes are detected
  def processChanges(): Unit = {
    var changeDetected = false

    val productRowCountBefore = Try {
      val hdfsDF = spark.read.parquet("hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/product_data")
      hdfsDF.count()
    }.getOrElse(0L)

    val customerRowCountBefore = Try {
      val hdfsDF = spark.read.parquet("hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/customer_data")
      hdfsDF.count()
    }.getOrElse(0L)

    val regionRowCountBefore = Try {
      val hdfsDF = spark.read.parquet("hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/region_data")
      hdfsDF.count()
    }.getOrElse(0L)

    if (hasDataChanged("ec_product_catalog", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/product_data")) {
      println("Product Catalog data changed, performing full load...")
      loadData("ec_product_catalog", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/product_data")
      changeDetected = true
    }

    if (hasDataChanged("ec_customer_data", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/customer_data")) {
      println("Customer data changed, performing full load...")
      loadData("ec_customer_data", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/customer_data")
      changeDetected = true
    }

    if (hasDataChanged("ec_region_data", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/region_data")) {
      println("Region data changed, performing full load...")
      loadData("ec_region_data", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/region_data")
      changeDetected = true
    }

    if (!changeDetected) {
      println("No changes detected in Product Catalog, Customer, or Region data.")
    }

    // Show max load timestamp for all tables after full load processing
    println("\nMax load timestamps after processing:")
    showMaxLoadTimestamp("hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/product_data", "Product Catalog")
    showMaxLoadTimestamp("hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/customer_data", "Customer Data")
    showMaxLoadTimestamp("hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/region_data", "Region Data")

    // Show row count comparison before and after
    println("\nRow count comparison after processing:")
    showRowCountComparison("hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/product_data", "Product Catalog", productRowCountBefore)
    showRowCountComparison("hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/customer_data", "Customer Data", customerRowCountBefore)
    showRowCountComparison("hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/region_data", "Region Data", regionRowCountBefore)
  }

  // Function to prompt the user for input and decide whether to check for changes
  def promptUser(): Boolean = {
    println("Do you want to check for changes in PostgreSQL? (yes/no)")
    val input = StdIn.readLine().trim.toLowerCase
    input == "yes"
  }

  // Main loop that asks the user if they want to check for changes
  def startJob(): Unit = {
    var continue = true
    while (continue) {
      if (promptUser()) {
        println("Checking for data changes...")
        processChanges()
      }

      // Optionally allow the user to exit the loop
      println("Do you want to continue checking for changes? (yes/no)")
      val continueInput = StdIn.readLine().trim.toLowerCase
      if (continueInput != "yes") {
        continue = false
      }
    }
  }

  // Start the job that asks the user for input
  startJob()

  // Stop the Spark session when the job ends
  spark.stop()
}
