import java.sql.Timestamp
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import scala.io.StdIn
import scala.util.Try

object UIIncrementLoad extends App {

  // HDFS path for incremental load
  final val INCREMENT_HDFS_PATH = "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022/tmp/deep/p1/ingestion_data/ui_data"

  val spark = SparkSession.builder()
    .appName("UIIncrementLoad")
    .config("spark.hadoop.fs.defaultFS", "hdfs://ip-172-31-3-80.eu-west-2.compute.internal:8022")
    .config("spark.jars", "/usr/local/lib/postgresql-42.2.18.jar")
    .getOrCreate()

  // Function to perform full or incremental load from PostgreSQL
  def loadData(tableName: String, hdfsPath: String, incremental: Boolean = false): Unit = {
    val jdbcUrl = DatabaseConnection.getJdbcUrl
    val jdbcProps = DatabaseConnection.getJdbcProperties

    // Query to fetch data from Postgres based on incremental flag
    val query = if (incremental) {
      val lastLoadTimestamp = getLastLoadTimestamp(hdfsPath)
      println(s"Last Load Timestamp: $lastLoadTimestamp")
      s"(SELECT * FROM $tableName WHERE click_timestamp > '$lastLoadTimestamp') AS user_interaction"
    } else {
      println("Performing full data load from PostgreSQL.")
      s"(SELECT * FROM $tableName) AS user_interaction"
    }

    // Load data from PostgreSQL
    val userInteractionDF = spark.read
      .option("header", "true")
      .jdbc(jdbcUrl, query, jdbcProps)

    // Ensure there are records to process
    if (userInteractionDF.count() > 0) {
      // Use the `click_timestamp` as the load timestamp
      val userInteractionWithTimestampDF = userInteractionDF
        .withColumn("click_timestamp", col("click_timestamp").cast("timestamp"))
        .withColumn("load_timestamp", col("click_timestamp"))

      // Row count before writing to HDFS
      val rowCountBefore = getHDFSRowCount(hdfsPath)
      println(s"Row count in HDFS before load: $rowCountBefore")

      // Write the data to HDFS in Parquet format, deduplicating the data
      userInteractionWithTimestampDF
        .dropDuplicates("click_timestamp", "user_id", "session_id")
        .write
        .mode(if (incremental) SaveMode.Append else SaveMode.Overwrite)
        .parquet(hdfsPath)

      // Show the newly added data
      println("Newly added data:")
      userInteractionWithTimestampDF.orderBy(desc("click_timestamp")).show(10)

      // Show the last 20 records from HDFS after appending
      println("Last 20 records from HDFS (including newly loaded data):")
      val hdfsDF = spark.read.parquet(hdfsPath)
      hdfsDF.orderBy(desc("click_timestamp")).show(20)

      // Row count after writing to HDFS
      val rowCountAfter = getHDFSRowCount(hdfsPath)
      println(s"Row count in HDFS after load: $rowCountAfter")

      // Compare row counts
      println(s"Row count added in this load: ${rowCountAfter - rowCountBefore}")

    } else {
      println("No new data found to load.")
    }
  }

  // Function to get the last load timestamp from HDFS
  def getLastLoadTimestamp(hdfsPath: String): Timestamp = {
    Try {
      val hdfsDF = spark.read.parquet(hdfsPath)
      hdfsDF.agg(max("click_timestamp")).collect()(0).getAs[Timestamp]("max(click_timestamp)")
    }.getOrElse(Timestamp.valueOf("1970-01-01 00:00:00")) // Return a default timestamp if no previous load exists
  }

  // Function to get row count from HDFS
  def getHDFSRowCount(hdfsPath: String): Long = {
    Try {
      val hdfsDF = spark.read.parquet(hdfsPath)
      hdfsDF.count()
    }.getOrElse(0L) // Return 0 if no data exists in HDFS
  }

  // Function to check if new data exists for incremental load
  def hasNewData(tableName: String, hdfsPath: String): Boolean = {
    val jdbcUrl = DatabaseConnection.getJdbcUrl
    val jdbcProps = DatabaseConnection.getJdbcProperties

    // Fetch the latest click_timestamp from PostgreSQL
    val query = s"(SELECT MAX(click_timestamp) as max_ts FROM $tableName) AS latest"
    val latestStatsDF = spark.read.jdbc(jdbcUrl, query, jdbcProps)

    // Extract the max timestamp from PostgreSQL
    val latestTimestamp = latestStatsDF.collect()(0).getAs[Timestamp]("max_ts")

    // Fetch the latest load timestamp from HDFS
    val lastLoadTimestamp = getLastLoadTimestamp(hdfsPath)

    // Compare the timestamps: If the latest timestamp in PostgreSQL is greater than the last loaded timestamp, return true
    latestTimestamp.after(lastLoadTimestamp)
  }

  // Main function to perform incremental loads
  def startJob(): Unit = {
    println("Starting data load process...")

    // Check if there is existing data in HDFS
    val isFullLoad = getLastLoadTimestamp(INCREMENT_HDFS_PATH) == Timestamp.valueOf("1970-01-01 00:00:00")

    if (isFullLoad) {
      println("No data found in HDFS. Performing full load...")
      loadData("ec_user_interaction", INCREMENT_HDFS_PATH, incremental = false) // Full load
    } else {
      println("HDFS contains data. Proceeding with incremental load...")
      loadData("ec_user_interaction", INCREMENT_HDFS_PATH, incremental = true) // Incremental load
    }

    // Prompt user to check for new data periodically
    while (true) {
      println("Do you want to perform an incremental load for new data? (yes/no)")
      val userResponse = StdIn.readLine().trim.toLowerCase

      if (userResponse == "yes") {
        println("Checking for new data in PostgreSQL...")
        if (hasNewData("ec_user_interaction", INCREMENT_HDFS_PATH)) {
          println("New data found, performing incremental load...")
          loadData("ec_user_interaction", INCREMENT_HDFS_PATH, incremental = true) // Incremental load
        } else {
          println("No new data found for incremental load.")
        }
      } else if (userResponse == "no") {
        println("Stopping the incremental load process. Goodbye!")
        sys.exit(0) // Exit the program
      } else {
        println("Invalid response. Please enter 'yes' or 'no'.")
      }
    }
  }

  // Start the data load job
  startJob()

  // Stop the Spark session when the job ends (this won't be reached due to the continuous loop)
  spark.stop()
}
