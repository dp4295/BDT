import boto3
import json
from datetime import datetime
from operator import itemgetter

# Initialize DynamoDB and SNS clients
dynamodb = boto3.resource('dynamodb')
sns_client = boto3.client('sns')
table = dynamodb.Table('uitable')

# SNS topic ARN
SNS_TOPIC_ARN = "arn:aws:sns:us-east-1:761018853894:RecentUserInteraction"

def lambda_handler(event, context):
    action_types = ['prdview', 'atc']
    max_unique_items = 3

    # Get user_id from event
    user_id = event.get("user_id")
    response = table.get_item(Key={'user_id': user_id})
    
    if 'Item' not in response:
        return {"status": "Error", "message": "User ID not found"}

    interactions = response['Item']['interactions']
    filtered_interactions = [i for i in interactions if i['action_type'] in action_types]
    filtered_interactions.sort(key=lambda x: x['click_timestamp'], reverse=True)

    # Keep only the most recent interaction for up to 3 unique products
    recent_interactions = []
    seen_products = set()
    for interaction in filtered_interactions:
        if interaction['product_id'] not in seen_products:
            recent_interactions.append(interaction)
            seen_products.add(interaction['product_id'])
        if len(seen_products) >= max_unique_items:
            break

    # Compose message for SNS
    subject = f"Please continue your shopping for most recent products."
    message = f"Hello  {user_id}:\n\n"
    for interaction in recent_interactions:
        message += (
            f"Action: {interaction['action_type']}\n"
            f"Product ID: {interaction['product_id']}\n"
            f"Timestamp: {interaction['click_timestamp']}\n"
            f"Region: {interaction['region']}\n"
            f"Source System: {interaction['source_system']}\n"
        )

    # Publish to SNS
    sns_client.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject=subject,
        Message=message
    )

    return {"status": "Success", "message": "Notification sent via SNS"}
