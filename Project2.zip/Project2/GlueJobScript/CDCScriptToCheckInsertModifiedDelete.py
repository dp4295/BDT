import sys
from pyspark.sql import functions as F
from pyspark.sql import DataFrame
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import json
from datetime import datetime
import boto3

# Initialize Glue context and Spark session
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'db_secret_name', 'region'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

def get_secret():
    """
    Retrieve database credentials from AWS Secrets Manager
    """
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=args['region']
    )
    
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=args['db_secret_name']
        )
    except Exception as e:
        raise e
    else:
        if 'SecretString' in get_secret_value_response:
            secret = json.loads(get_secret_value_response['SecretString'])
            return secret

# Get database credentials from Secrets Manager
db_credentials = get_secret()

# Define PostgreSQL connection properties
jdbc_properties = {
    "user": db_credentials['username'],
    "password": db_credentials['password'],
    "driver": "org.postgresql.Driver"
}

# Define S3 paths where the data will be stored
s3_base_path = "s3://elevatexsys/raw/postgressql_data/"

def read_from_postgresql(table_name):
    """
    Helper function to read data from PostgreSQL
    """
    return spark.read.format("jdbc").options(
        url=db_credentials['jdbc_url'],
        dbtable=table_name,
        user=jdbc_properties["user"],
        password=jdbc_properties["password"],
        driver=jdbc_properties["driver"]
    ).load()

def read_from_s3(table_name):
    """
    Helper function to read existing data from S3 in Parquet format
    """
    s3_path = s3_base_path + f"{table_name}/"
    try:
        return spark.read.parquet(s3_path)
    except:
        # If there's no data in S3 yet, return an empty DataFrame with the same schema as PostgreSQL
        return spark.createDataFrame(spark.sparkContext.emptyRDD(), read_from_postgresql(table_name).schema)

def compare_datasets(postgres_df, s3_df, primary_key_columns):
    """
    Helper function to compare data and identify changes
    """
    # Alias to avoid column conflicts during join
    postgres_df = postgres_df.alias('postgres_df')
    s3_df = s3_df.alias('s3_df')

    # Identify new rows (inserted in PostgreSQL but not in S3)
    new_rows = postgres_df.join(s3_df, primary_key_columns, "leftanti")

    # Identify deleted rows (exist in S3 but not in PostgreSQL)
    deleted_rows = s3_df.join(postgres_df, primary_key_columns, "leftanti")

    # Identify modified rows (exist in both but have different values)
    join_conditions = [postgres_df[col] == s3_df[col] for col in primary_key_columns]
    common_rows = postgres_df.join(s3_df, join_conditions, "inner")
    
    # Select only columns from postgres_df to avoid duplicates in modified rows
    modified_rows = common_rows.filter(F.expr(" OR ".join(
        [f"postgres_df.{col} <> s3_df.{col}" for col in postgres_df.columns if col not in primary_key_columns]
    ))).select([f"postgres_df.{col}" for col in postgres_df.columns])

    return new_rows, deleted_rows, modified_rows

def process_table_changes(postgres_df, s3_df, table_name, primary_key_columns):
    """
    Process changes for a table and return change statistics
    """
    new_rows, deleted_rows, modified_rows = compare_datasets(
        postgres_df, s3_df, primary_key_columns
    )
    
    # Get counts
    new_count = new_rows.count() if not new_rows.rdd.isEmpty() else 0
    deleted_count = deleted_rows.count() if not deleted_rows.rdd.isEmpty() else 0
    modified_count = modified_rows.count() if not modified_rows.rdd.isEmpty() else 0
    
    # Handle data operations
    if not new_rows.rdd.isEmpty():
        new_rows.write.mode("append").parquet(s3_base_path + f"{table_name}/")
        
    if not modified_rows.rdd.isEmpty():
        modified_rows.write.mode("append").parquet(s3_base_path + f"{table_name}/")
    
    if not deleted_rows.rdd.isEmpty():
        print(f"Deleted rows found in {table_name}:")
        deleted_rows.show()
    
    return {
        "table_name": table_name,
        "new_records": new_count,
        "modified_records": modified_count,
        "deleted_records": deleted_count,
        "total_changes": new_count + modified_count + deleted_count
    }

# Process all tables and collect changes
all_changes = []

# 1. Process Product Catalog Table
product_changes = process_table_changes(
    read_from_postgresql("ec_product_catalog"),
    read_from_s3("product_catalog"),
    "product_catalog",
    ["product_id"]
)
all_changes.append(product_changes)

# 2. Process Customer Data
customer_changes = process_table_changes(
    read_from_postgresql("ec_customer_data"),
    read_from_s3("customer_data"),
    "customer_data",
    ["user_id"]
)
all_changes.append(customer_changes)

# 3. Process Region Data
region_changes = process_table_changes(
    read_from_postgresql("ec_region_data"),
    read_from_s3("region_data"),
    "region_data",
    ["region_code"]
)
all_changes.append(region_changes)

# Calculate totals
total_changes = sum(change["total_changes"] for change in all_changes)
total_new = sum(change["new_records"] for change in all_changes)
total_modified = sum(change["modified_records"] for change in all_changes)
total_deleted = sum(change["deleted_records"] for change in all_changes)

# Prepare result object
result = {
    "total_changes": total_changes,
    "new_records": total_new,
    "modified_records": total_modified,
    "deleted_records": total_deleted,
    "tables_processed": len(all_changes),
    "timestamp": datetime.now().isoformat(),
    "details": all_changes
}

# Print result in a format that Step Functions can parse
print("CHANGE_DETECTION_RESULT=" + json.dumps(result))

# Commit the job
job.commit()