import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

# Get job arguments
args = getResolvedOptions(sys.argv, ['JOB_NAME'])

# Initialize Glue context and Spark session
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Define PostgreSQL connection information
jdbc_url = "jdbc:postgresql://ec2-18-132-73-146.eu-west-2.compute.amazonaws.com/testdb"
jdbc_properties = {
    "user": "consultants",
    "password": "WelcomeItc@2022",
    "driver": "org.postgresql.Driver"
}


# Define the S3 path where the data will be saved
s3_output_path = "s3://elevatexsys/raw/postgressql_data/"

# 1. Extract Product Catalog
df_product_catalog = spark.read.format("jdbc").options(
    url=jdbc_url,
    dbtable="ec_product_catalog",
    user=jdbc_properties["user"],
    password=jdbc_properties["password"],
    driver=jdbc_properties["driver"]
).load()

# Write Product Catalog to S3
df_product_catalog.write.format("parquet").mode("overwrite").save(s3_output_path + "product_catalog/")

# 2. Extract Customer Data
df_customer_data = spark.read.format("jdbc").options(
    url=jdbc_url,
    dbtable="ec_customer_data",
    user=jdbc_properties["user"],
    password=jdbc_properties["password"],
    driver=jdbc_properties["driver"]
).load()

# Write Customer Data to S3
df_customer_data.write.format("parquet").mode("overwrite").save(s3_output_path + "customer_data/")

# 3. Extract Region Data
df_region_data = spark.read.format("jdbc").options(
    url=jdbc_url,
    dbtable="ec_region_data",
    user=jdbc_properties["user"],
    password=jdbc_properties["password"],
    driver=jdbc_properties["driver"]
).load()

# Write Region Data to S3
df_region_data.write.format("parquet").mode("overwrite").save(s3_output_path + "region_data/")

# Commit the job
job.commit()