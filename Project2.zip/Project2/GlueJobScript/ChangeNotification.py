import sys
from pyspark.sql import functions as F
from pyspark.sql import DataFrame
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import boto3
import json
from datetime import datetime

# Initialize Glue context and job
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'SNS_TOPIC_ARN'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

def generate_change_report(table_name, new_rows, deleted_rows, modified_rows):
    """
    Generate a detailed report of changes for a specific table
    """
    new_count = new_rows.count() if not new_rows.rdd.isEmpty() else 0
    deleted_count = deleted_rows.count() if not deleted_rows.rdd.isEmpty() else 0
    modified_count = modified_rows.count() if not modified_rows.rdd.isEmpty() else 0
    
    return {
        "table_name": table_name,
        "new_records": new_count,
        "deleted_records": deleted_count,
        "modified_records": modified_count,
        "total_changes": new_count + deleted_count + modified_count,
        "timestamp": datetime.now().isoformat()
    }

def process_table_with_notification(postgres_df, s3_df, table_name, primary_key_columns):
    """
    Process a table and generate notifications for changes
    """
    new_rows, deleted_rows, modified_rows = compare_datasets(
        postgres_df, s3_df, primary_key_columns
    )
    
    # Generate change report
    change_report = generate_change_report(table_name, new_rows, deleted_rows, modified_rows)
    
    # Handle data operations as before
    if not new_rows.rdd.isEmpty():
        new_rows.write.mode("append").parquet(s3_base_path + f"{table_name}/")
        
    if not modified_rows.rdd.isEmpty():
        modified_rows.write.mode("append").parquet(s3_base_path + f"{table_name}/")
    
    return change_report

# Process all tables and collect reports
table_configs = [
    {
        "name": "product_catalog",
        "postgres_table": "ec_product_catalog",
        "primary_key": ["product_id"]
    },
    {
        "name": "customer_data",
        "postgres_table": "ec_customer_data",
        "primary_key": ["user_id"]
    },
    {
        "name": "region_data",
        "postgres_table": "ec_region_data",
        "primary_key": ["region_code"]
    }
]

all_reports = []
total_changes = 0

# Process each table
for config in table_configs:
    df_postgres = read_from_postgresql(config["postgres_table"])
    df_s3 = read_from_s3(config["name"])
    
    report = process_table_with_notification(
        df_postgres,
        df_s3,
        config["name"],
        config["primary_key"]
    )
    
    all_reports.append(report)
    total_changes += report["total_changes"]

# Prepare result for Step Functions
result = {
    "total_changes": total_changes,
    "new_records": sum(report["new_records"] for report in all_reports),
    "modified_records": sum(report["modified_records"] for report in all_reports),
    "deleted_records": sum(report["deleted_records"] for report in all_reports),
    "tables_processed": len(table_configs),
    "timestamp": datetime.now().isoformat(),
    "details": all_reports
}

# Print the result for Step Functions to capture
print("CHANGE_DETECTION_RESULT=" + json.dumps(result))

# Commit the job
job.commit()