import sys
from pyspark.sql import functions as F
from pyspark.sql import DataFrame
from pyspark.sql import Window 
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

# Initialize Glue context and Spark session
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init('data_cleaning_job', {})

# Define S3 paths
raw_s3_base_path = "s3://elevatexsys/raw/postgressql_data/"
clean_s3_base_path = "s3://elevatexsys/clean/data/"

# Helper function to read data from S3 in Parquet format
def read_from_s3_clean(table_name):
    s3_path = raw_s3_base_path + f"{table_name}/"
    return spark.read.parquet(s3_path)

# Helper function to clean data (remove duplicates, drop nulls)
def clean_data(df, primary_key_columns):
    # Remove rows with null values in primary key columns
    for col in primary_key_columns:
        df = df.filter(F.col(col).isNotNull())
    
    # Remove duplicate rows based on primary keys, keeping the latest based on timestamp or another criteria
    window_spec = Window.partitionBy(*primary_key_columns).orderBy(F.desc("last_modified_timestamp"))
    df = df.withColumn("row_num", F.row_number().over(window_spec))
    df = df.filter(F.col("row_num") == 1).drop("row_num")
    
    return df

# Function to write cleaned data to clean S3 path
def write_cleaned_data(df, table_name):
    s3_path = clean_s3_base_path + f"{table_name}/"
    df.write.mode("overwrite").parquet(s3_path)

# Process Product Catalog Table
df_product_catalog = read_from_s3_clean("product_catalog")
df_cleaned_product_catalog = clean_data(df_product_catalog, ["product_id"])
write_cleaned_data(df_cleaned_product_catalog, "product_catalog")

# Process Customer Data
df_customer_data = read_from_s3_clean("customer_data")
df_cleaned_customer_data = clean_data(df_customer_data, ["user_id"])
write_cleaned_data(df_cleaned_customer_data, "customer_data")

# Process Region Data
df_region_data = read_from_s3_clean("region_data")
df_cleaned_region_data = clean_data(df_region_data, ["region_code"])
write_cleaned_data(df_cleaned_region_data, "region_data")

# Commit the job
job.commit()
