import json
import random
from datetime import datetime, timedelta
import boto3
import logging

# Set up logging property
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize Kinesis client
kinesis_client = boto3.client("kinesis")
STREAM_NAME = "ui-stream"

# Predefined data lists
products = ['P972210', 'P91563', 'P63074', 'P45825', 'P27248', 'P83148', 'P17089', 'P77404']
user_ids = ['U9202773856', 'U4242347668', 'U4928297432', 'U1844555267', 'U2952343762']
sessions = ['S341887', 'S178905', 'S478684', 'S176001', 'S321671', 'S582754', 'S414201', 'S867688']
regions = ['MX', 'CA', 'EU', 'NA']
action_types = ['atc', 'prdview', 'purchase']
source_systems = ['MobileAppLogs', 'WebAppLogs', 'BackendLogs']

def generate_user_interaction():
    return {
        "click_timestamp": int(datetime.now().timestamp() * 1000),  # Current timestamp in milliseconds
        "user_id": random.choice(user_ids),
        "session_id": random.choice(sessions),
        "product_id": random.choice(products),
        "action_type": random.choice(action_types),
        "region": random.choice(regions),
        "source_system": random.choice(source_systems)
    }

def lambda_handler(event, context):
    try:
        # Log the incoming event
        logger.info(f"Received event: {json.dumps(event)}")
        
        # Specify how many records to generate per Lambda invocation
        num_records = event.get('num_records', 5)
        successful_records = 0
        
        for i in range(num_records):
            try: 
                record = generate_user_interaction()
                logger.info(f"Sending record {i+1}: {json.dumps(record)}")
                
                # Send to Kinesis
                response = kinesis_client.put_record(
                    StreamName=STREAM_NAME,
                    Data=json.dumps(record),
                    PartitionKey="partitionkey"
                )
                
                successful_records += 1
                logger.info(f"Successfully sent record {i+1}: {json.dumps(response)}")
            except Exception as e:
                logger.error(f"Error sending record {i+1}: {str(e)}")
                continue
            
        if successful_records == num_records:
            return {
                "status": "Success",
                "message": f"Successfully sent {successful_records} records to Kinesis",
                "records_sent": successful_records
            }
        else:
            return {
                "status": "Error",
                "message": f"Partially successful: Sent {successful_records} out of {num_records} records",
                "records_sent": successful_records
            }
            
    except Exception as e:
        error_msg = f"Fatal error in producer: {str(e)}"
        logger.error(error_msg)
        return {
            "status": "Error",
            "message": str(e),
            "records_sent": 0
        }