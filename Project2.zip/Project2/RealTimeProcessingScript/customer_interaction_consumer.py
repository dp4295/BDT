
import json
import boto3
import base64
from botocore.exceptions import ClientError

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("uitable")

def lambda_handler(event, context):
    try:
        # Check if this is a monitoring request from Step Functions
        if 'checkStatus' in event:
            
            return {
                "status": "Success",
                "message": "Consumer status check completed"
            }
            
        # Handle Kinesis records
        if 'Records' in event:
            for record in event['Records']:
                # Decode the Kinesis data from base64
                data = json.loads(base64.b64decode(record['kinesis']['data']).decode('utf-8'))
                
                # Extract user_id and interaction details
                user_id = data["user_id"]
                interaction = {
                    "click_timestamp": data["click_timestamp"],
                    "session_id": data["session_id"],
                    "product_id": data["product_id"],
                    "action_type": data["action_type"],
                    "region": data["region"],
                    "source_system": data["source_system"]
                }
                
                # Update the DynamoDB item for this user_id
                update_dynamodb(user_id, interaction)
            
            return {
                "status": "Success", 
                "message": f"Successfully processed {len(event['Records'])} records"
            }
            
        return {
            "status": "Error",
            "message": "Invalid event structure - neither monitoring request nor Kinesis records found"
        }
    
    except Exception as e:
        print("Error processing records:", e)
        return {"status": "Error", "message": str(e)}

def update_dynamodb(user_id, interaction):
    try:
        table.update_item(
            Key={"user_id": user_id},
            UpdateExpression="SET interactions = list_append(if_not_exists(interactions, :empty_list), :new_interaction)",
            ExpressionAttributeValues={
                ":new_interaction": [interaction],
                ":empty_list": []
            },
            ReturnValues="UPDATED_NEW"
        )
        print(f"Updated DynamoDB for user_id {user_id} with interaction: {interaction}")
    except ClientError as e:
        print(f"Error updating DynamoDB for user_id {user_id}: {e}")
        raise e  # Re-raise the error to be caught by the main try-except block